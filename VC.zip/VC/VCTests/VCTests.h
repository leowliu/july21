//
//  VCTests.h
//  VCTests
//
//  Created by Benny on 7/23/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>


@interface VCTests : SenTestCase {
@private
    
}

@end
