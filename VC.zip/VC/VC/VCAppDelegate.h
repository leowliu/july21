//
//  VCAppDelegate.h
//  VC
//
//  Created by Benny on 7/23/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
@class ViewController;

@interface VCAppDelegate : NSObject <UIApplicationDelegate> {
	ViewController *viewController;
	UIWindow *_window;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@end
